-- Tabella dei gatti presenti nel sito (versione MySQL / MariaDB)
-- Si può importare da phpMyAdmin, oppure usare installa.php

CREATE TABLE IF NOT EXISTS gatti (
    id               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    nome             VARCHAR(100) NOT NULL,
    sesso            ENUM('M', 'F') NULL,
    data_nascita     DATE NULL,
    razza            VARCHAR(100) NULL,
    colore           VARCHAR(100) NULL,
    descrizione      TEXT NULL,
    foto             VARCHAR(255) NULL,          -- percorso, es. img/gatti/micio.jpg
    data_inserimento DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Dati di esempio
INSERT INTO gatti (nome, sesso, data_nascita, razza, colore, descrizione, foto) VALUES
('Micio', 'M', '2024-03-15', 'Europeo', 'Tigrato grigio', 'Descrizione del gatto.', 'img/gatti/micio.jpg'),
('Fuffi', 'F', '2022-07-01', 'Persiano', 'Bianco',        'Descrizione del gatto.', 'img/gatti/fuffi.jpg');
