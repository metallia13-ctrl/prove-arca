<?php
// Configurazione generale del sito
define('NOME_SITO', 'Il mio sito');

// ---- Database ----
// 'sqlite' = file locale, nessun server da configurare (comodo per iniziare)
// 'mysql'  = per hosting con MySQL/MariaDB (es. phpMyAdmin): compila i dati sotto
define('DB_DRIVER', 'sqlite');

define('DB_SQLITE_FILE', __DIR__ . '/../database/gatti.sqlite');

define('DB_HOST', 'localhost');
define('DB_NOME', 'nome_database');
define('DB_UTENTE', 'utente');
define('DB_PASSWORD', 'password');

// Voci del menù: chiave = id pagina, valore = [titolo, file]
// L'ordine qui è l'ordine in cui appaiono nel menù: spostale come preferisci.
$MENU = [
    'gattinder' => ['titolo' => 'gatTinder',       'file' => 'pagine/gattinder.php'],
    'home'      => ['titolo' => 'Home',            'file' => 'pagine/home.php'],
    'chi-siamo' => ['titolo' => 'Chi siamo',       'file' => 'pagine/chi-siamo.php'],
    'eventi'    => ['titolo' => 'Bacheca eventi',  'file' => 'pagine/bacheca-eventi.php'],
];
