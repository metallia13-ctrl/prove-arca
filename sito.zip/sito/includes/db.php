<?php
// Connessione al database (PDO). Uso: $pdo = db();
function db(): PDO
{
    static $pdo = null;
    if ($pdo !== null) {
        return $pdo;
    }

    $opzioni = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ];

    if (DB_DRIVER === 'mysql') {
        $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NOME . ';charset=utf8mb4';
        $pdo = new PDO($dsn, DB_UTENTE, DB_PASSWORD, $opzioni);
    } else {
        $pdo = new PDO('sqlite:' . DB_SQLITE_FILE, null, null, $opzioni);
    }

    return $pdo;
}

// Restituisce tutti i gatti presenti nel sito
function elencoGatti(): array
{
    return db()->query('SELECT * FROM gatti ORDER BY nome')->fetchAll();
}

// Restituisce un singolo gatto per id, oppure null
function trovaGatto(int $id): ?array
{
    $stmt = db()->prepare('SELECT * FROM gatti WHERE id = ?');
    $stmt->execute([$id]);
    return $stmt->fetch() ?: null;
}

// Calcola l'età a partire dalla data di nascita (es. "2 anni", "5 mesi")
function etaGatto(?string $dataNascita): string
{
    if (!$dataNascita) {
        return 'età sconosciuta';
    }
    $diff = (new DateTime($dataNascita))->diff(new DateTime());
    if ($diff->y > 0) {
        return $diff->y . ($diff->y === 1 ? ' anno' : ' anni');
    }
    return $diff->m . ($diff->m === 1 ? ' mese' : ' mesi');
}
