</main>

<footer>
    <p>&copy; <?= date('Y') ?> <?= htmlspecialchars(NOME_SITO) ?></p>
</footer>

</body>
</html>
