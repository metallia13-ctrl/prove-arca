<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($titoloPagina) ?> — <?= htmlspecialchars(NOME_SITO) ?></title>
</head>
<body>

<header>
    <h1><a href="index.php"><?= htmlspecialchars(NOME_SITO) ?></a></h1>
    <?php include __DIR__ . '/menu.php'; ?>
</header>

<main>
