<nav>
    <ul>
        <?php foreach ($MENU as $id => $voce): ?>
            <li>
                <a href="index.php?pagina=<?= urlencode($id) ?>"
                   <?= $id === $paginaCorrente ? 'aria-current="page"' : '' ?>>
                    <?= htmlspecialchars($voce['titolo']) ?>
                </a>
            </li>
        <?php endforeach; ?>
    </ul>
</nav>
