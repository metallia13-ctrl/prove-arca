<?php
require __DIR__ . '/includes/config.php';

// Pagina richiesta (default: home). Solo le pagine presenti nel menù sono ammesse.
$paginaCorrente = $_GET['pagina'] ?? 'home';
if (!array_key_exists($paginaCorrente, $MENU)) {
    http_response_code(404);
    $paginaCorrente = 'home';
}

$titoloPagina = $MENU[$paginaCorrente]['titolo'];

include __DIR__ . '/includes/header.php';
include __DIR__ . '/' . $MENU[$paginaCorrente]['file'];
include __DIR__ . '/includes/footer.php';
