<?php
// Crea la tabella "gatti" e inserisce i dati di esempio.
// Aprilo UNA volta nel browser (o da terminale: php installa.php), poi CANCELLALO dal server.
require __DIR__ . '/includes/config.php';
require __DIR__ . '/includes/db.php';

$pdo = db();

if (DB_DRIVER === 'mysql') {
    $pdo->exec("CREATE TABLE IF NOT EXISTS gatti (
        id               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        nome             VARCHAR(100) NOT NULL,
        sesso            ENUM('M', 'F') NULL,
        data_nascita     DATE NULL,
        razza            VARCHAR(100) NULL,
        colore           VARCHAR(100) NULL,
        descrizione      TEXT NULL,
        foto             VARCHAR(255) NULL,
        data_inserimento DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
} else {
    $pdo->exec("CREATE TABLE IF NOT EXISTS gatti (
        id               INTEGER PRIMARY KEY AUTOINCREMENT,
        nome             TEXT NOT NULL,
        sesso            TEXT NULL CHECK (sesso IN ('M', 'F')),
        data_nascita     TEXT NULL,
        razza            TEXT NULL,
        colore           TEXT NULL,
        descrizione      TEXT NULL,
        foto             TEXT NULL,
        data_inserimento TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    )");
}

// Inserisce i dati di esempio solo se la tabella è vuota
$quanti = (int) $pdo->query('SELECT COUNT(*) FROM gatti')->fetchColumn();
if ($quanti === 0) {
    $stmt = $pdo->prepare('INSERT INTO gatti (nome, sesso, data_nascita, razza, colore, descrizione, foto)
                           VALUES (?, ?, ?, ?, ?, ?, ?)');
    $stmt->execute(['Micio', 'M', '2024-03-15', 'Europeo',  'Tigrato grigio', 'Descrizione del gatto.', 'img/gatti/micio.jpg']);
    $stmt->execute(['Fuffi', 'F', '2022-07-01', 'Persiano', 'Bianco',         'Descrizione del gatto.', 'img/gatti/fuffi.jpg']);
}

echo 'Database pronto. Gatti presenti: ' . $pdo->query('SELECT COUNT(*) FROM gatti')->fetchColumn()
   . '. Ora cancella installa.php dal server.';
