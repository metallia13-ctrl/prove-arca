<?php
// Dati di esempio: in futuro potranno arrivare da un database
$eventi = [
    ['titolo' => 'Evento 1', 'data' => '2026-12-05', 'luogo' => 'Luogo 1', 'descrizione' => 'Descrizione evento 1.'],
    ['titolo' => 'Evento 2', 'data' => '2026-12-20', 'luogo' => 'Luogo 2', 'descrizione' => 'Descrizione evento 2.'],
];
?>
<section id="bacheca-eventi">
    <h2>Bacheca eventi</h2>

    <?php if (empty($eventi)): ?>
        <p>Nessun evento in programma.</p>
    <?php else: ?>
        <?php foreach ($eventi as $evento): ?>
            <article>
                <h3><?= htmlspecialchars($evento['titolo']) ?></h3>
                <p>
                    <time datetime="<?= htmlspecialchars($evento['data']) ?>">
                        <?= date('d/m/Y', strtotime($evento['data'])) ?>
                    </time>
                    — <?= htmlspecialchars($evento['luogo']) ?>
                </p>
                <p><?= htmlspecialchars($evento['descrizione']) ?></p>
            </article>
        <?php endforeach; ?>
    <?php endif; ?>
</section>
