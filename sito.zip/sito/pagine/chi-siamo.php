<section id="chi-siamo">
    <h2>Chi siamo</h2>

    <section>
        <h3>La nostra storia</h3>
        <p>Testo sulla storia del gruppo.</p>
    </section>

    <section>
        <h3>Il team</h3>
        <ul>
            <li>Nome Cognome — ruolo</li>
            <li>Nome Cognome — ruolo</li>
        </ul>
    </section>

    <section>
        <h3>Contatti</h3>
        <p>Email: <a href="mailto:info@esempio.it">info@esempio.it</a></p>
    </section>
</section>
