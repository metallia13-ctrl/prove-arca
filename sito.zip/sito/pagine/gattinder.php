<?php
require_once __DIR__ . '/../includes/db.php';

// Se nell'indirizzo c'è ?gatto=ID mostra la scheda di quel gatto, altrimenti l'elenco
$idGatto = isset($_GET['gatto']) ? (int) $_GET['gatto'] : 0;

try {
    $gatto = $idGatto > 0 ? trovaGatto($idGatto) : null;
    $gatti = $idGatto > 0 ? [] : elencoGatti();
    $erroreDb = false;
} catch (PDOException $e) {
    $gatto = null;
    $gatti = [];
    $erroreDb = true;
}
?>
<section id="gattinder">
    <h2>gatTinder</h2>

    <?php if ($erroreDb): ?>
        <p>Il database dei gatti non è disponibile al momento.</p>

    <?php elseif ($idGatto > 0): ?>
        <!-- Scheda del singolo gatto -->
        <?php if (!$gatto): ?>
            <p>Gatto non trovato.</p>
        <?php else: ?>
            <article>
                <?php if ($gatto['foto']): ?>
                    <img src="<?= htmlspecialchars($gatto['foto']) ?>" alt="Foto di <?= htmlspecialchars($gatto['nome']) ?>">
                <?php endif; ?>
                <h3><?= htmlspecialchars($gatto['nome']) ?></h3>
                <dl>
                    <dt>Sesso</dt>  <dd><?= $gatto['sesso'] === 'F' ? 'Femmina' : ($gatto['sesso'] === 'M' ? 'Maschio' : '—') ?></dd>
                    <dt>Età</dt>    <dd><?= etaGatto($gatto['data_nascita']) ?></dd>
                    <dt>Razza</dt>  <dd><?= htmlspecialchars($gatto['razza'] ?? '—') ?></dd>
                    <dt>Colore</dt> <dd><?= htmlspecialchars($gatto['colore'] ?? '—') ?></dd>
                </dl>
                <p><?= nl2br(htmlspecialchars($gatto['descrizione'] ?? '')) ?></p>
            </article>
        <?php endif; ?>
        <p><a href="index.php?pagina=gattinder">&larr; Tutti i gatti</a></p>

    <?php elseif (empty($gatti)): ?>
        <p>Nessun gatto presente.</p>

    <?php else: ?>
        <!-- Elenco dei gatti -->
        <p>I gatti presenti nel sito:</p>
        <?php foreach ($gatti as $g): ?>
            <article>
                <?php if ($g['foto']): ?>
                    <img src="<?= htmlspecialchars($g['foto']) ?>" alt="Foto di <?= htmlspecialchars($g['nome']) ?>">
                <?php endif; ?>
                <h3><?= htmlspecialchars($g['nome']) ?>, <?= etaGatto($g['data_nascita']) ?></h3>
                <p><a href="index.php?pagina=gattinder&amp;gatto=<?= (int) $g['id'] ?>">Vedi scheda</a></p>
            </article>
        <?php endforeach; ?>
    <?php endif; ?>
</section>
