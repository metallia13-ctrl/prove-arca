<section id="home">
    <h2>Benvenuti</h2>
    <p>Testo di presentazione del sito.</p>

    <section>
        <h3>Ultimi eventi</h3>
        <p><a href="index.php?pagina=eventi">Vai alla bacheca eventi</a></p>
    </section>

    <section>
        <h3>gatTinder</h3>
        <p><a href="index.php?pagina=gattinder">Scopri i gatti</a></p>
    </section>
</section>
